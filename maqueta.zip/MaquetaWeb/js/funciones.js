// Funciones JS opcionales
console.log("Página cargada");

